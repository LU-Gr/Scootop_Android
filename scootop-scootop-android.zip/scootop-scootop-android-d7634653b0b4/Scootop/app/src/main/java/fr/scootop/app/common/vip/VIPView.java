package fr.scootop.app.common.vip;

public interface VIPView
{

}
