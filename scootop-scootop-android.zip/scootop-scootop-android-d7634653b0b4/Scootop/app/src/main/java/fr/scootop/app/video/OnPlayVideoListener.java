package fr.scootop.app.video;

public interface OnPlayVideoListener
{
    void onPlayYoutubeVideo(String videoId);
}
