package fr.scootop.app.common

interface IMessagingView {

    fun displayError(message: String)

    fun displayInfo(message: String)
}