package fr.scootop.app.common.vip;

public interface LoadingPresenter extends VIPView
{
	void presentLoading();

	void dismissLoading();
}
