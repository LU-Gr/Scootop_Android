package fr.scootop.app.common

interface ILoadingView {

    fun displayLoading()

    fun hideLoading()
}