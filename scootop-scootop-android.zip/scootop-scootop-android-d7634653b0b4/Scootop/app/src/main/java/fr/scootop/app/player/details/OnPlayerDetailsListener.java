package fr.scootop.app.player.details;

import fr.scootop.data.model.Player;

/**
 * Created by ludovicriviere on 05/03/2018.
 */
public interface OnPlayerDetailsListener
{
    void onDisplayPlayerDetails(Player player);
}
