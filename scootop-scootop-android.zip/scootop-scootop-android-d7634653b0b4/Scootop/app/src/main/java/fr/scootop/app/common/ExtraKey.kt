package fr.scootop.app.common

object ExtraKey {

    val PLAYER_ITEM = "extra.player_item"
    val PLAYER = "extra.player"
    val PLAYER_ID = "extra.player_id"

    val USER_ID = "extra.user_id"
    val USER_TYPE = "extra.user_type"
}
