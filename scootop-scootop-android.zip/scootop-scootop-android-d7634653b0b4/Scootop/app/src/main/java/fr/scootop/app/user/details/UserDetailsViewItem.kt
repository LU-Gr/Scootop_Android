package fr.scootop.app.user.details

class UserDetailsViewItem(val type: UserDetailsViewType) {

}