package fr.scootop.app.shortlist;

public interface OnShortlistUserListener
{
    void onDisplayPlayer(Integer playerId);
}
