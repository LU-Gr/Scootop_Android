package fr.scootop.app.user.details

import fr.scootop.data.model.Player

class UserDetailsViewBuilder {

    fun getItems(player: Player): Array<UserDetailsViewItem> {

        return emptyArray()
    }
}