package fr.scootop.app.common.vip;

public interface LoadingView extends VIPView
{
	void showLoading();

	void hideLoading();
}
